
function handleLogin(event) {
  event.preventDefault();
  const email = document.getElementById('appleid').value;
  const password = document.getElementById('password').value;
  alert(`Tentative de connexion avec:\nEmail: ${email}\nMot de passe: ${'*'.repeat(password.length)}`);
}
